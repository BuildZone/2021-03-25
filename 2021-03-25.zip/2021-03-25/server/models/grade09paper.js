const mongoose = require('mongoose')

module.exports =mongoose.model('grade09paper',{
    name:String,
    paperPath:String,
   
   
    subjectname:String

})
