const mongoose = require('mongoose')

module.exports =mongoose.model('grade08paper',{
    name:String,
    paperPath:String,
   
   
    subjectname:String

})
