import { Component, OnInit } from '@angular/core';
import { MessageService } from '../message.service';

@Component({
  selector: 'app-messages-inbox',
  templateUrl: './messages-inbox.component.html',
  styleUrls: ['./messages-inbox.component.css']
})
export class MessagesInboxComponent implements OnInit {

  constructor( private _messageService : MessageService) { }

  messages = []

  ngOnInit(): void {

    this._messageService.getMessages()
    .subscribe(
      res => {
        this.messages = res
      },
      err => {
        console.log(err)
      }
    )


  }

}
