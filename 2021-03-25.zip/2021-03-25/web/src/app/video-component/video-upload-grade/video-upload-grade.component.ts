import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-upload-grade',
  templateUrl: './video-upload-grade.component.html',
  styleUrls: ['./video-upload-grade.component.css']
})
export class VideoUploadGradeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
