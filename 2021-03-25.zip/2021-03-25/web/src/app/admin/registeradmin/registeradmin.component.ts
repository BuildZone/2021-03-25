import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registeradmin',
  templateUrl: './registeradmin.component.html',
  styleUrls: ['./registeradmin.component.css']
})
export class RegisteradminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
