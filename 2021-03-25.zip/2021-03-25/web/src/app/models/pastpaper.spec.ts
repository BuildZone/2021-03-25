import { Pastpaper } from './pastpaper';

describe('Pastpaper', () => {
  it('should create an instance', () => {
    expect(new Pastpaper()).toBeTruthy();
  });
});
